document.addEventListener("DOMContentLoaded", function () {
  const methods = document.querySelectorAll(".payment-method");

  methods.forEach((method) => {
    method.addEventListener("click", () => {
      const paymentMethod = method.dataset.method;
      const bookingId = document.querySelector("#bookingId").value; // Ambil ID booking dari elemen HTML

      fetch("/create-payment", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          payment_method: paymentMethod,
          booking_id: bookingId,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.token) {
            window.location.href = `https://app.sandbox.midtrans.com/snap/v2/vtweb/${data.token}`;
          } else {
            alert("Gagal membuat transaksi.");
          }
        })
        .catch(() => {
          alert("Terjadi kesalahan.");
        });
    });
  });
});
