from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from flask import flash
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import midtransclient
from dotenv import load_dotenv
import os

load_dotenv()
midtrans_core_api = midtransclient.CoreApi(
    is_production=False,
    server_key=os.getenv('MIDTRANS_SERVER_KEY'),
    client_key=os.getenv('MIDTRANS_CLIENT_KEY')
)

def format_rupiah(amount):
    try:
        formatted = f"Rp {amount:,.0f}".replace(",", ".")
        return formatted
    except ValueError:
        return "Rp 0"
    
app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///basing_event.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/images'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

db = SQLAlchemy(app)
migrate = Migrate(app, db)
ADMIN_EMAIL = 'basingevent3030@gmail.com'
ADMIN_PASSWORD = '********'


@app.context_processor
def utility_processor():
    return {"format_rupiah": format_rupiah}

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(15), nullable=False)
    password = db.Column(db.String(255), nullable=False)

class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    date = db.Column(db.String(50), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    general_price = db.Column(db.Float, nullable=False, default=0.0)
    vip_price = db.Column(db.Float, nullable=False, default=0.0)
    student_price = db.Column(db.Float, nullable=False, default=0.0)
    image_path = db.Column(db.String(200), nullable=True, default=None)

    def price_range(self):
        prices = [self.general_price, self.vip_price, self.student_price]
        prices = [p for p in prices if p > 0]  # Hanya harga valid (di atas 0)
        if not prices:
            return "Tidak tersedia"
        return f"{format_rupiah(min(prices))} - {format_rupiah(max(prices))}"

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    ticket_category = db.Column(db.String(50), nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    order_id = db.Column(db.String(50), nullable=True)  # Order ID Midtrans
    user = db.relationship('User', backref='bookings')

    # DATABASE DISIMPAN DI FOLDER: instance/basing_event.db

def get_booking_details():
    # Ambil booking_id dari parameter URL
    booking_id = request.args.get('booking_id')  
    if not booking_id:
        raise ValueError("Booking ID tidak ditemukan di URL.")
    
    # Query database untuk mendapatkan booking
    booking = Booking.query.get(booking_id)  
    if not booking:
        raise ValueError("Booking tidak ditemukan.")
    
    return booking

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/create_event', methods=['GET', 'POST'])
def create_event():
    if request.method == 'POST':
        name = request.form['name']
        date = request.form['date']
        location = request.form['location']
        description = request.form['description']

        general_price = request.form.get('general_price', type=float, default=0.0)
        vip_price = request.form.get('vip_price', type=float, default=0.0)
        student_price = request.form.get('student_price', type=float, default=0.0)
        
        # Cek apakah file gambar ada
        if 'image' not in request.files:
            return "No file part", 400

        image = request.files['image']
        if image.filename == '':
            return "No selected file", 400

        # Periksa apakah gambar ada dan memiliki ekstensi yang valid
        if image and allowed_file(image.filename):
            filename = secure_filename(image.filename)
            
            # Buat folder jika belum ada
            if not os.path.exists(app.config['UPLOAD_FOLDER']):
                os.makedirs(app.config['UPLOAD_FOLDER'])

            image.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            image_path = os.path.join('static', 'images', filename).replace("\\", "/")  # Path gambar relatif untuk disimpan di database

            # Simpan event baru ke database
            new_event = Event(name=name, date=date, location=location, description=description, general_price=general_price, vip_price=vip_price, student_price=student_price, image_path=image_path)
            db.session.add(new_event)
            db.session.commit()
            return redirect(url_for('create_event'))

    return render_template('create_event.html')

# Routes
@app.route('/', methods=['GET', 'POST'])
def home():
    user_logged_in = 'user_id' in session  # Periksa apakah pengguna sudah login

    if request.method == 'POST':
        search_query = request.form.get('search', '').strip()
        if search_query:
            events = Event.query.filter(
                Event.name.ilike(f"%{search_query}%") | Event.location.ilike(f"%{search_query}%")
            ).all()
            if not events:
                flash("Tidak ada event yang sesuai dengan pencarian Anda.", "info")
        else:
            events = Event.query.all()
    else:
        events = Event.query.all()
    
    for event in events:
        event.price_range_display = event.price_range()

    return render_template('home.html', events=events, user_logged_in=user_logged_in)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

         # Jika login sebagai admin
        if email == ADMIN_EMAIL and password == ADMIN_PASSWORD:
            session['user_id'] = 'admin'
            return redirect(url_for('create_event'))

        # Cari user berdasarkan email
        user = User.query.filter_by(email=email).first()

        # Jika user ditemukan dan password cocok
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            return redirect(url_for('home'))
        else:
            flash("Login gagal. Periksa kembali e-mail & password anda.", "login_error")
            return redirect(url_for('login'))  # Redirect untuk membersihkan flash sebelumnya
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    # Inisialisasi variabel dengan nilai default (None atau '')
    full_name = email = phone = password = confirm_password = None

    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']
        phone = request.form['phone']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # Validasi form
        if not full_name or not email or not phone or not password or not confirm_password:
            flash("Semua field harus diisi!", "register_error")
            return redirect(url_for('register'))

        if password != confirm_password:
            flash("Password dan konfirmasi password tidak cocok!", "register_error")
            return redirect(url_for('register'))

        # Periksa apakah email sudah terdaftar
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("Email sudah terdaftar, silakan gunakan email lain!", "register_error")
            return redirect(url_for('register'))

        # Hash password sebelum menyimpannya
        hashed_password = generate_password_hash(password)

        # Simpan user ke database
        try:
            new_user = User(full_name=full_name, email=email, phone=phone, password=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            flash("Pendaftaran berhasil! Silakan login.", "success")
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash("Terjadi kesalahan saat menyimpan data. Silakan coba lagi.", "register_error")
            print(f"Error saat menyimpan data: {e}")  # Debugging
            return redirect(url_for('register'))

    return render_template('register.html')

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        flash("Anda harus login terlebih dahulu", "error")
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if user is None:
        flash("Pengguna tidak ditemukan", "error")
        return redirect(url_for('login'))
    
    return render_template('profile.html', user=user)

@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/admin/logout', methods=['POST'])
def admin_logout():
    session.clear()  # Hapus data sesi admin
    return redirect(url_for('login'))

@app.route('/event/<int:event_id>', methods=['GET', 'POST'])
def event_detail(event_id):
    user_logged_in = 'user_id' in session
    # Ambil event berdasarkan ID
    event = Event.query.get(event_id)
    if event is None:
        return "Event not found", 404
    
    if event.image_path.startswith('static/'):
        event.image_url = event.image_path[len('static/'):]  # Hapus "static/" di depan path
    else:
        event.image_url = event.image_path  # Path sudah sesuai

    print(f"Event Image Path: {event.image_path}")  # Debugging

    # Cek apakah pengguna sudah login
    if 'user_id' not in session:
        flash("Anda harus login untuk memesan tiket.", "error")
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        ticket_category = request.form.get('ticket_category')

        # Validasi harga tiket
        prices = {
            'general': event.general_price,
            'vip': event.vip_price,
            'student': event.student_price
        }

        if ticket_category not in prices:
            return "Invalid ticket category", 400
        
        price = prices[ticket_category]

        # Buat detail booking
        user_id = session['user_id']
        booking = Booking(user_id=user_id, event_id=event_id, ticket_category=ticket_category, total_price=price)
        db.session.add(booking)
        db.session.commit()

        # Redirect ke halaman pembayaran
        return redirect(url_for('payment', booking_id=booking.id))
    return render_template('event_detail.html', event=event, user_logged_in=user_logged_in)

@app.route('/payment', methods=['GET'])
def payment():
    booking_id = request.args.get('booking_id')
    if not booking_id:
        flash("Booking ID tidak ditemukan.", "error")
        return redirect(url_for('home'))
    
    booking = Booking.query.get_or_404(booking_id)
    return render_template('payment.html', booking=booking)

@app.route('/create-payment', methods=['POST'])
def create_payment():
    data = request.json
    print("Received data:", data)  # Tambahkan log untuk memeriksa data yang dikirimkan dari frontend

    booking_id = data.get('booking_id')
    payment_method = data.get('payment_method')

    if not booking_id or not payment_method:
        print("Missing booking_id or payment_method")  # Log jika ada data yang hilang
        return jsonify({"error": "Booking ID or Payment Method missing"}), 400

    # Cari booking berdasarkan ID
    booking = Booking.query.get(booking_id)
    if not booking:
        print(f"Booking with ID {booking_id} not found.")  # Log jika booking tidak ditemukan
        return jsonify({"error": "Booking not found"}), 404

    print("Booking found:", booking)

    # Inisialisasi Snap Midtrans
    snap = midtransclient.Snap(
        is_production=False,  # Pastikan menggunakan mode sandbox
        server_key=os.getenv('MIDTRANS_SERVER_KEY')
    )

    params = {
        "transaction_details": {
            "order_id": f"booking-{booking.id}",
            "gross_amount": booking.total_price,
        },
        "customer_details": {
            "first_name": booking.user.full_name.split(" ")[0],
            "last_name": " ".join(booking.user.full_name.split(" ")[1:]),
            "email": booking.user.email,
            "phone": booking.user.phone,
        },
        "enabled_payments": [payment_method],
        "callbacks": {
            "finish": url_for('success', _external=True)
        }
    }

    if payment_method == "bank_transfer":
        params["bank_transfer"] = {"bank": "bca"}  # Sesuaikan dengan bank yang didukung
    elif payment_method not in ["gopay", "dana", "bank_transfer"]:
        print(f"Unsupported payment method: {payment_method}")  # Log jika metode pembayaran tidak didukung
        return jsonify({"error": "Unsupported payment method"}), 400

    try:
        transaction = snap.create_transaction(params)
        print("Transaction created successfully:", transaction)  # Log jika transaksi berhasil
        return jsonify({"token": transaction['token']})  # Return token transaksi
    except Exception as e:
        print(f"Error creating transaction: {e}")  # Log error jika ada masalah saat membuat transaksi
        return jsonify({"error": str(e)}), 500

@app.route('/success')
def success():
    booking_id = request.args.get('booking_id')
    if not booking_id:
        flash("Booking ID tidak ditemukan.", "error")
        return redirect(url_for('home'))
    
    # Panggil API Midtrans untuk memvalidasi status transaksi
    order_id = f"booking-{booking_id}"
    snap = midtransclient.Snap(
        is_production=False,  # Pastikan mode sandbox
        server_key=os.getenv('MIDTRANS_SERVER_KEY')
    )
    
    try:
        # Menggunakan API untuk memeriksa status transaksi
        transaction = snap.transactions.status(order_id)
        transaction_status = transaction.get('transaction_status')

        if transaction_status == "settlement":
            # Update status pembayaran ke "Paid" di database
            booking = Booking.query.get(booking_id)
            if booking:
                booking.status = "Paid"
                db.session.commit()

            return render_template('success.html', booking=booking)
        else:
            flash("Pembayaran belum selesai atau gagal.", "error")
            return redirect(url_for('home'))
    except Exception as e:
        print(f"Error: {e}")
        flash("Gagal memvalidasi transaksi.", "error")
        return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)